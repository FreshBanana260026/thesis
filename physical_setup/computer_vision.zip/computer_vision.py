import pyrealsense2 as rs
import numpy as np
import cv2 as cv


class D435:
    def __init__(self):
        self.pipeline = rs.pipeline()
        self.config = rs.config()
        self.config.enable_stream(rs.stream.depth, 1280, 720, rs.format.z16, 30)
        self.config.enable_stream(rs.stream.color, 640, 360, rs.format.bgr8, 30)
        self.pipeline.start(self.config)
        self.align_to = rs.stream.color
        self.align = rs.align(self.align_to)
        self.consistency_cnt = 0
        self.area = None
        self.centroid = None
        self.angle = None

    def get_frame(self):
        frames = self.pipeline.wait_for_frames()
        aligned_frames = self.align.process(frames)
        depth_frame = aligned_frames.get_depth_frame()
        color_frame = aligned_frames.get_color_frame()
        return depth_frame, color_frame

    def check_consistency(self, area, centroid, angle):
        if self.area is None or self.centroid is None:
            self.area = area
            self.centroid = centroid
            return False
        #print("Area: ", self.area, "Centroid: ", self.centroid)
        #print("Area: ", area, "Centroid: ", centroid)
        if abs(self.area - area) < 100 and abs(self.centroid[0] - centroid[0]) < 10 and abs(self.centroid[1] - centroid[1]) < 10 and abs(self.angle - self.angle) < 5:
            self.consistency_cnt += 1
            self.area = area
            self.centroid = centroid
            self.angle = angle
        else:
            self.consistency_cnt = 0

        if self.consistency_cnt > 50:
            self.consistency_cnt = 51
            return True

        return False

    def find_object(self):
        while True:
            depth_frame, color_frame = self.get_frame()

            depth_image = np.asanyarray(depth_frame.get_data())/1000
            color_image = np.asanyarray(color_frame.get_data())

            # Make image grayscale
            gray = cv.cvtColor(color_image, cv.COLOR_BGR2GRAY)

            # Crop image to only picking area
            cropped_image = gray[145:284, 171:521]

            # Apply blurring and sharpening
            blur = cv.medianBlur(cropped_image, 5)
            sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpen = cv.filter2D(blur, -1, sharpen_kernel)

            # Threshold and morph
            thresh = cv.threshold(sharpen, 120, 255, cv.THRESH_BINARY_INV)[1]
            kernel = cv.getStructuringElement(cv.MORPH_RECT, (3,3))
            close = cv.morphologyEx(thresh, cv.MORPH_CLOSE, kernel, iterations=2)

            # Find contours and filter using threshold area
            cnts = cv.findContours(close, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
            cnts = cnts[0] if len(cnts) == 2 else cnts[1]

            min_area = 2000
            max_area = 6500
            rectangles = []
            area = 0

            for c in cnts:
                epsilon = 0.04 * cv.arcLength(c, True)
                approx = cv.approxPolyDP(c, epsilon, True)
                area = cv.contourArea(c)
                if area > min_area and area < max_area and len(approx) == 4:
                    x,y,w,h = cv.boundingRect(c)
                    rectangles.append(approx)

            if len(rectangles) > 0:
                item_contour = rectangles[0]
            else:
                #print("No item found")
                continue

            M = cv.moments(item_contour)
            angle_degrees = 0
            if M["m00"] != 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])

                angle = 0.5 * np.arctan2(2 * M["mu11"], (M["mu20"] - M["mu02"]))
                angle_degrees = np.degrees(angle)
            else:
                cx, cy = 0, 0

            real_centroid_x = cx + 171
            real_centroid_y = cy + 145

            centroid = (real_centroid_x, real_centroid_y, depth_image[real_centroid_y][real_centroid_x])

            angle = np.deg2rad(angle_degrees)

            center = np.array([real_centroid_x, real_centroid_y])
            arrow_size = 130
            point = np.array([real_centroid_x, real_centroid_y + arrow_size])
            point_y = np.array([real_centroid_x + arrow_size, real_centroid_y])

            cos_theta = np.cos(angle)
            sin_theta = np.sin(angle)
            rotated_point = center + np.dot(np.array([[cos_theta, -sin_theta], [sin_theta, cos_theta]]), point - center)
            rotated_point = rotated_point.astype(int)

            rotated_point_y = center + np.dot(np.array([[cos_theta, -sin_theta], [sin_theta, cos_theta]]), point_y - center)
            rotated_point_y = rotated_point_y.astype(int)

            output = cv.arrowedLine(color_image, (real_centroid_x, real_centroid_y), (rotated_point[0], rotated_point[1]), (255, 0, 0), 2, tipLength = 0.3)  #x-axis
            output = cv.arrowedLine(output, (real_centroid_x, real_centroid_y), (rotated_point_y[0], rotated_point_y[1]), (0, 200, 0), 2, tipLength = 0.3)  #y-axis

            if self.check_consistency(area, center, angle_degrees):
                print("Item found")
            else:
                self.area = area
                self.centroid = center
                self.angle = angle_degrees
                print("Item not found")
                continue
            print("Area: ", area, "Centroid: ", centroid, "Angle: ", angle_degrees)
            cv.namedWindow('RealSense', cv.WINDOW_AUTOSIZE)
            cv.imshow('RealSense', output)
            cv.waitKey(1)

    def show_frames(self):
        i = 0
        while True:
            depth_frame, color_frame = self.get_frame()

            depth_image = np.asanyarray(depth_frame.get_data())
            color_image = np.asanyarray(color_frame.get_data())
            #if i == 50:
            #    cv.imwrite("depth_image.png", depth_image)
            #    cv.imwrite("color_image.png", color_image)
            #    break
            # downsize images
            #depth_image = depth_image[140:280, 200:500]
            #color_image = color_image[140:280, 200:500]
            # Apply colormap on depth image (image must be converted to 8-bit per pixel first)
            depth_colormap = cv.applyColorMap(cv.convertScaleAbs(depth_image, alpha=0.03), cv.COLORMAP_JET)

            depth_colormap_dim = depth_colormap.shape
            color_colormap_dim = color_image.shape
            print(depth_colormap_dim)
            print(color_colormap_dim)

            # If depth and color resolutions are different, resize color image to match depth image for display
            if depth_colormap_dim != color_colormap_dim:
                resized_color_image = cv.resize(color_image, dsize=(depth_colormap_dim[1], depth_colormap_dim[0]), interpolation=cv.INTER_AREA)
                images = np.hstack((resized_color_image, depth_colormap))
            else:
                images = np.hstack((color_image, depth_colormap))
            i += 1
            # Show images
            cv.namedWindow('RealSense', cv.WINDOW_AUTOSIZE)
            cv.imshow('RealSense', images)
            cv.waitKey(1)
